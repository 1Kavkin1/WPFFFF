using System;
using System.Collections.Generic;
using System.Linq;

namespace WPF.Models
{
    public abstract class People
    {
        public string FullName { get; set; } = string.Empty;
        public int Age { get; set; }
        public object TypeName { get; internal set; }
        public object ExtraInfo { get; internal set; }

        public abstract string ToFileString();
        public abstract string ToDisplayString();
    }

    public class Student : People
    {
        public double GradeAverage { get; set; }
        public string University { get; set; } = string.Empty;

        public override string ToFileString()
        {
            return $"STUDENT|{FullName}|{Age}|{GradeAverage}|{University}";
        }

        public override string ToDisplayString()
        {
            return $"Student: {FullName}, Age {Age}, Avg {GradeAverage}, {University}";
        }
    }

    public class Teacher : People
    {
        public string Subject { get; set; } = string.Empty;
        public decimal Salary { get; set; }

        public override string ToFileString()
        {
            return $"TEACHER|{FullName}|{Age}|{Subject}|{Salary}";
        }

        public override string ToDisplayString()
        {
            return $"Teacher: {FullName}, Age {Age}, Subject {Subject}, Salary {Salary}";
        }
    }

    public static class PeopleFactory
    {
        private static readonly Random Rnd = new Random();

        public static People ParseLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line)) return null!;
            var parts = line.Split('|');
            if (parts.Length == 0) return null!;
            var tag = parts[0].ToUpperInvariant();
            try
            {
                if (tag == "STUDENT" && parts.Length >= 5)
                {
                    return new Student
                    {
                        FullName = parts[1],
                        Age = int.Parse(parts[2]),
                        GradeAverage = double.Parse(parts[3]),
                        University = parts[4]
                    };
                }

                if (tag == "TEACHER" && parts.Length >= 5)
                {
                    return new Teacher
                    {
                        FullName = parts[1],
                        Age = int.Parse(parts[2]),
                        Subject = parts[3],
                        Salary = decimal.Parse(parts[4])
                    };
                }
            }
            catch
            {
                // ignore parse errors
            }

            // fallback: simple Student
            return new Student { FullName = line, Age = 0, GradeAverage = 0, University = string.Empty };
        }

        public static IEnumerable<People> GenerateRandom(int count)
        {
            var first = new[] { "Олександр", "Марія", "Іван", "Олена", "Дмитро", "Катерина", "Петро", "Наталя" };
            var last = new[] { "Шевченко", "Коваль", "Петренко", "Бондар", "Іваненко", "Гончар" };
            var unis = new[] { "КНУ", "ЛНУ", "НТУ", "ХНУ" };
            var subjects = new[] { "Math", "Physics", "History", "Biology" };

            for (int i = 0; i < count; i++)
            {
                if (Rnd.NextDouble() < 0.5)
                {
                    yield return new Student
                    {
                        FullName = $"{first[Rnd.Next(first.Length)]} {last[Rnd.Next(last.Length)]}",
                        Age = Rnd.Next(18, 30),
                        GradeAverage = Math.Round(2.0 + Rnd.NextDouble() * 3.0, 2),
                        University = unis[Rnd.Next(unis.Length)]
                    };
                }
                else
                {
                    yield return new Teacher
                    {
                        FullName = $"{first[Rnd.Next(first.Length)]} {last[Rnd.Next(last.Length)]}",
                        Age = Rnd.Next(25, 65),
                        Subject = subjects[Rnd.Next(subjects.Length)],
                        Salary = Rnd.Next(20000, 80000)
                    };
                }
            }
        }
    }
}
