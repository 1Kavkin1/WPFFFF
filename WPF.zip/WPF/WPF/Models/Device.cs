using System;

namespace WPF.Models
{
    public abstract class Device
    {
        public string Brand { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public decimal Price { get; set; }

        protected abstract string GetDetails();

        public override string ToString() => GetDetails();
    }

    public class Smartphone : Device
    {
        public string Cpu { get; set; } = string.Empty;
        public int Memory { get; set; }
        public int Storage { get; set; }
        public double ScreenSize { get; set; }

        protected override string GetDetails()
        {
            return $"Smartphone: {Brand} {Model} — {Price:F2} UAH | CPU: {Cpu} | RAM: {Memory}GB | Storage: {Storage}GB | Screen: {ScreenSize}";
        }
    }

    public class Laptop : Device
    {
        public string Cpu { get; set; } = string.Empty;
        public int Memory { get; set; }
        public int Storage { get; set; }
        public string Display { get; set; } = string.Empty;

        protected override string GetDetails()
        {
            return $"Laptop: {Brand} {Model} — {Price:F2} UAH | CPU: {Cpu} | RAM: {Memory}GB | Storage: {Storage}GB | Display: {Display}";
        }
    }
}
