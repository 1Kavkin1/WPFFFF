namespace WPF.Models
{
    public class Animal
    {
        public string Name { get; set; }
        public string Species { get; set; }
        public string Emoji { get; set; }
        public string Description { get; set; }
    }
}
