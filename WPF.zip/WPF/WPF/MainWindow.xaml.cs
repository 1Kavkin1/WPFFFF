﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WPF.Models;
using System.Text;

namespace WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Device> Devices { get; } = new ObservableCollection<Device>();
        private ObservableCollection<Animal> Animals { get; } = new ObservableCollection<Animal>();

        public MainWindow()
        {
            InitializeComponent();

            // Setup collections
            DevicesListBox.ItemsSource = Devices;
            AnimalsItemsControl.ItemsSource = Animals;

            // Wire events
            DeviceTypeCombo.SelectionChanged += DeviceTypeCombo_SelectionChanged;

            // Seed animals
            SeedAnimals();
        }

        private void DeviceTypeCombo_SelectionChanged(object? sender, SelectionChangedEventArgs e)
        {
            var sel = (DeviceTypeCombo.SelectedItem as ComboBoxItem)?.Content?.ToString();
            if (string.Equals(sel, "Laptop", StringComparison.OrdinalIgnoreCase))
            {
                SmartphonePanel.Visibility = Visibility.Collapsed;
                LaptopPanel.Visibility = Visibility.Visible;
            }
            else
            {
                SmartphonePanel.Visibility = Visibility.Visible;
                LaptopPanel.Visibility = Visibility.Collapsed;
            }
        }

        private void AddDeviceBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var type = (DeviceTypeCombo.SelectedItem as ComboBoxItem)?.Content?.ToString();
                var brand = BrandText.Text?.Trim() ?? string.Empty;
                var model = ModelText.Text?.Trim() ?? string.Empty;

                if (!decimal.TryParse(PriceText.Text?.Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out var price))
                {
                    MessageBox.Show("Введіть коректну ціну", "Помилка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (string.Equals(type, "Laptop", StringComparison.OrdinalIgnoreCase))
                {
                    var cpu = LaptopCpuText.Text?.Trim() ?? string.Empty;
                    int.TryParse(LaptopMemoryText.Text?.Trim(), out var mem);
                    int.TryParse(LaptopStorageText.Text?.Trim(), out var stor);
                    var display = DisplayText.Text?.Trim() ?? string.Empty;

                    var laptop = new Laptop
                    {
                        Brand = brand,
                        Model = model,
                        Price = price,
                        Cpu = cpu,
                        Memory = mem,
                        Storage = stor,
                        Display = display
                    };
                    Devices.Add(laptop);
                }
                else
                {
                    var cpu = CpuText.Text?.Trim() ?? string.Empty;
                    int.TryParse(MemoryText.Text?.Trim(), out var mem);
                    int.TryParse(StorageText.Text?.Trim(), out var stor);
                    double.TryParse(ScreenText.Text?.Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out var screen);

                    var phone = new Smartphone
                    {
                        Brand = brand,
                        Model = model,
                        Price = price,
                        Cpu = cpu,
                        Memory = mem,
                        Storage = stor,
                        ScreenSize = screen
                    };
                    Devices.Add(phone);
                }

                // Clear inputs
                BrandText.Text = ModelText.Text = PriceText.Text = string.Empty;
                CpuText.Text = MemoryText.Text = StorageText.Text = ScreenText.Text = string.Empty;
                LaptopCpuText.Text = LaptopMemoryText.Text = LaptopStorageText.Text = DisplayText.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка додавання: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RemoveDeviceBtn_Click(object sender, RoutedEventArgs e)
        {
            if (DevicesListBox.SelectedItem is Device d)
            {
                Devices.Remove(d);
            }
        }

        private void SeedAnimals()
        {
            Animals.Clear();
            Animals.Add(new Animal { Name = "Кіт", Species = "Felis catus", Emoji = "🐱", Description = "М'який, допитливий товариш." });
            Animals.Add(new Animal { Name = "Собака", Species = "Canis familiaris", Emoji = "🐶", Description = "Вірний і життєрадісний супутник." });
            Animals.Add(new Animal { Name = "Єнот", Species = "Procyon lotor", Emoji = "🦝", Description = "Кмітливий дрібний хижак з милою 'маскою'" });
            Animals.Add(new Animal { Name = "Капібара", Species = "Hydrochoerus hydrochaeris", Emoji = "🦫", Description = "Найбільший гризун — неймовірно спокійний." });
            Animals.Add(new Animal { Name = "Панда", Species = "Ailuropoda melanoleuca", Emoji = "🐼", Description = "Тиха і чарівна, любить бамбук." });
        }

        private void RenderAnimalCards()
        {
            AnimalsItemsControl.Items.Clear();
            foreach (var a in Animals)
            {
                var border = new Border
                {
                    CornerRadius = new CornerRadius(12),
                    Background = System.Windows.Media.Brushes.Transparent,
                    Margin = new Thickness(8),
                    Padding = new Thickness(8)
                };

                var card = new Border
                {
                    CornerRadius = new CornerRadius(12),
                    Background = System.Windows.Media.Brushes.DimGray,
                    Width = 220,
                    MinHeight = 140,
                    Padding = new Thickness(12)
                };

                var sp = new StackPanel();
                var emoji = new TextBlock { Text = a.Emoji, FontSize = 36 };
                var name = new TextBlock { Text = a.Name, FontSize = 16, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 8, 0, 0) };
                var species = new TextBlock { Text = a.Species, FontSize = 12, Foreground = System.Windows.Media.Brushes.LightGray };
                var desc = new TextBlock { Text = a.Description, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 0) };

                sp.Children.Add(emoji);
                sp.Children.Add(name);
                sp.Children.Add(species);
                sp.Children.Add(desc);

                card.Child = sp;
                border.Child = card;

                AnimalsItemsControl.Items.Add(border);
            }
        }

        private void GeneratePeopleBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var people = PeopleFactory.GenerateRandom(10);
                var basePath = AppDomain.CurrentDomain.BaseDirectory;
                var file = Path.Combine(basePath, "people_data.txt");
                var lines = people.Select(p => p.ToFileString()).ToArray();
                File.WriteAllLines(file, lines);

                // Read back
                var readLines = File.ReadAllLines(file);
                var parsed = new List<People>();
                foreach (var ln in readLines)
                {
                    var p = PeopleFactory.ParseLine(ln);
                    if (p != null) parsed.Add(p);
                }

                // Map to view objects
                var view = parsed.Select(p => new
                {
                    TypeName = p.TypeName,
                    FullName = p.FullName,
                    Age = p.Age,
                    ExtraInfo = p.ExtraInfo
                }).ToList();

                PeopleListView.ItemsSource = view;
                PeopleStatusText.Text = $"Saved and read {view.Count} people to: {file}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

